package com.example.pateltravels;

public interface TaskCompleted {
    void onTaskComplete(String result);
}
