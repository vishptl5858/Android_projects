package com.example.pateltravels;

public interface GetData {
    void onGetData(String result);
}
