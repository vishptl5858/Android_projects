package com.example.pateltravels;

public interface GetRecyclerData {
    void onGetRecyclerData(int id, String name, int rent, int av);
    void onGetMakeAdminRecyclerData(String name);
}
